<?php

namespace Drupal\little_helpers\Field;

interface BundleInterface {
  public function getEntityType();
  public function getBundleName();
}
